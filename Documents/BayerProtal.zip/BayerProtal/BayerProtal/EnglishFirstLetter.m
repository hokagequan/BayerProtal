//
//  EnglishFirstLetter.m
//  BayerProtal
//
//  Created by admin on 14-11-6.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "EnglishFirstLetter.h"


@implementation EnglishFirstLetter

@dynamic firstLetter;

@end
