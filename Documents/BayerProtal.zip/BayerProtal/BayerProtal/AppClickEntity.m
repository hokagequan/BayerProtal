//
//  AppClickEntity.m
//  BayerProtal
//
//  Created by 尹现伟 on 14/10/27.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "AppClickEntity.h"


@implementation AppClickEntity

@dynamic idStr;
@dynamic clickCount;

@end
