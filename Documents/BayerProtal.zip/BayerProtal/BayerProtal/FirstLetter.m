//
//  FirstLetter.m
//  BayerProtal
//
//  Created by admin on 14-10-23.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import "FirstLetter.h"


@implementation FirstLetter

@dynamic firstLetter;

@end
