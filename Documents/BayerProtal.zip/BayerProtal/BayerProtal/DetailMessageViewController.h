//
//  DetailMessageViewController.h
//  BayerProtal
//
//  Created by admin on 14-10-21.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BYinformation.h"

@interface DetailMessageViewController : UIViewController

@property(nonatomic,strong) BYinformation *information;


@end
