//
//  AppCatagery.m
//  BayerProtal
//
//  Created by admin on 14-11-12.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "AppCatagery.h"


@implementation AppCatagery

@dynamic catageryId;
@dynamic chineseName;
@dynamic englishName;
@dynamic imagUrl;

@end
