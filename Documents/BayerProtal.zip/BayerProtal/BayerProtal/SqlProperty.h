//
//  SqlProperty.h
//  BayerProtal
//
//  Created by admin on 14-10-15.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SqlProperty : NSObject

+(NSMutableArray *)getPropertyOfTheClass:(char *)myClass;

@end
