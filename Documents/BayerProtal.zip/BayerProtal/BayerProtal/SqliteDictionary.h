//
//  SqliteDictionary.h
//  BayerProtal
//
//  Created by admin on 14-10-13.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SqliteDictionary : NSObject

+(NSDictionary *)getTheKeys:(NSArray *)keyArry AndValues:(NSArray *)valueArray;

@end
