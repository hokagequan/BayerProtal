//
//  SetTableViewCell.h
//  BayerProtal
//
//  Created by admin on 14-10-19.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetTableViewCell : UITableViewCell

-(void)initFirstTypeWith:(NSArray *)array;

-(void)initSecondTypeWith:(NSArray *)array andKey:(NSString *)key;

@end
