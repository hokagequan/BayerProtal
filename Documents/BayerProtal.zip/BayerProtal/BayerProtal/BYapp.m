//
//  BYapp.m
//  BayerProtal
//
//  Created by admin on 14-11-6.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "BYapp.h"


@implementation BYapp

@dynamic appCategoryId;
@dynamic appCDescription;
@dynamic appId;
@dynamic appIma;
@dynamic appCname;
@dynamic appUrl;
@dynamic clickCount;
@dynamic chineseFirstLetter;
@dynamic appEname;
@dynamic appEDescription;
@dynamic englishFirstLetter;

@end
