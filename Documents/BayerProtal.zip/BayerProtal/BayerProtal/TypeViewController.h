//
//  TypeViewController.h
//  BayerProtal
//
//  Created by admin on 14-10-20.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import "BossViewController.h"

@interface TypeViewController : BossViewController

@property (nonatomic,strong)NSString * AppCategoryId;

@end
