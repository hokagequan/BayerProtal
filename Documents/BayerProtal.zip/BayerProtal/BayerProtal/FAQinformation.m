//
//  FAQinformation.m
//  BayerProtal
//
//  Created by admin on 14-10-29.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "FAQinformation.h"


@implementation FAQinformation

@dynamic content;
@dynamic faqId;
@dynamic title;

@end
