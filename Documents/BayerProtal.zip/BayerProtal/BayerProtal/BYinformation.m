//
//  BYinformation.m
//  BayerProtal
//
//  Created by admin on 14-11-21.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "BYinformation.h"


@implementation BYinformation

@dynamic createTime;
@dynamic information;
@dynamic informationId;
@dynamic isRead;
@dynamic userGroup;
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end
