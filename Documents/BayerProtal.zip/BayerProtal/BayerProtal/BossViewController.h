//
//  BossViewController.h
//  BayerProtal
//
//  Created by admin on 14-9-28.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BossViewController : UIViewController

@property (nonatomic,strong) UIView *navgationView;

@property (nonatomic,strong) UILabel *titleLabel;

@property(nonatomic,strong) UIImageView *lognBT;

@property (nonatomic,strong) UIButton * BackBt;




@end
