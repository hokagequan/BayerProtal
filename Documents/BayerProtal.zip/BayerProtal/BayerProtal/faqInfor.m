//
//  faqInfor.m
//  BayerProtal
//
//  Created by admin on 14-10-22.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import "faqInfor.h"

@implementation faqInfor



@end
