//
//  EnglishFirstLetter.h
//  BayerProtal
//
//  Created by admin on 14-11-6.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface EnglishFirstLetter : NSManagedObject

@property (nonatomic, retain) NSString * firstLetter;

@end
