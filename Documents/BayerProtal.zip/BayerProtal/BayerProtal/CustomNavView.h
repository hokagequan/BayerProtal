//
//  CustomNavView.h
//  BayerProtal
//
//  Created by bts on 15/10/27.
//  Copyright (c) 2015年 DNE Technology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavView : UIView
@property (nonatomic,retain) UILabel *titleLabel;

@end
