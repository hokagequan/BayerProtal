//
//  LastViewController.h
//  BayerProtal
//
//  Created by admin on 14-9-25.
//  Copyright (c) 2014年 ___DNEUSER___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LastViewController : UIViewController

@property (nonatomic,strong) UIView *navView;








@end
