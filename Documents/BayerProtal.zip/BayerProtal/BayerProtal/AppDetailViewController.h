//
//  AppDetailViewController.h
//  BayerProtal
//
//  Created by admin on 14-11-24.
//  Copyright (c) 2014年 DNE Technology Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDetailViewController : UIViewController

@property (nonatomic,strong) NSString *appId;
@end
