//
//  CustomNavView.m
//  BayerProtal
//
//  Created by bts on 15/10/27.
//  Copyright (c) 2015年 DNE Technology Co.,Ltd. All rights reserved.
//

#import "CustomNavView.h"

@implementation CustomNavView

- (instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        [self loadBasicView];
    }
    return self;
}
- (void)loadBasicView{

    
    
}

@end
